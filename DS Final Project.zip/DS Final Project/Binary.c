#include <stdio.h>
#include <stdlib.h>

struct node {
	int info;
	struct node* l;
	struct node* r;
};

struct node* newNode(int info)
{
	struct node* node = (struct node*)malloc(sizeof(struct node));
	node->info = info;
	node->l = NULL;
	node->r = NULL;

	return (node);
}

void Postorder(struct node* node)
{
	if (node == NULL)
		return;
	Postorder(node->l);
	Postorder(node->r);
	printf("%d\n", node->info);
}

void Inorder(struct node* node)
{
	if (node == NULL)
		return;
	Inorder(node->l);
	printf("%d\n", node->info);
	Inorder(node->r);
}

void Preorder(struct node* node)
{
	if (node == NULL)
		return;
	printf("%d\n", node->info);
	Preorder(node->l);
	Preorder(node->r);
}

int main()
{
    int n,o;
	printf("Enter the no. of elements you want to insert: ");
	scanf("%d ",n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	struct node* root = newNode(a[0]);
	root->l = newNode(a[1]);
	root->r = newNode(a[2]);
	root->l->l = newNode(a[3]);
	root->l->r = newNode(a[4]);
	printf("Preorder traversal of binary tree is \n");
	Preorder(root);
	printf("\nInorder traversal of binary tree is \n");
	Inorder(root);
	printf("\nPostorder traversal of binary tree is \n");
	Postorder(root);
	return 0;
}