#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int info;
    struct Node *link;
};
void display(struct Node *); 
struct Node * insertfirst(int, struct Node *);
struct Node* insertend(int, struct Node *);
struct Node* insertbetween (int, struct Node *);
struct Node* delete(int,struct Node *); 
int countnodes(struct Node *);
struct Node* copy(struct Node *);

void main()
{
    struct Node *first,*begin;
    int i,ch,no;
    first = (struct Node*)malloc(sizeof(struct Node));
    first=NULL;
    while(ch!=8)
    {
        printf("\n1.insert at begin\n2.Insert at last\n3.Insert in between\n4.Delete\n5.Copy Linked List\n6.Count nodes\n7.Display LinkedList\n8.Exit");
        printf("\nEnter the choice : ");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:
                  printf("Enter the value you want to insert : ");
                  scanf("%d",&no);
                  first=insertfirst(no,first);
                  break;
            case 2:
                  printf("Enter the value you want to insert : ");
                  scanf("%d",&no);
                  first=insertend(no,first);
                  break;
            case 3:
                  printf("Enter the value you want to insert : ");
                  scanf("%d",&no);
                  first=insertbetween(no,first);
                  break;
            case 4:
                  printf("Enter the value you want to delete : ");
                  scanf("%d",&no);
                  first=delete(no,first);
                  break;
            case 5:
                  printf("The copied linked list is : ");
                  begin=copy(first);
                  break;
            case 6:
                  i=printf("The total number of nodes are %d",countnodes(first));
                  break;
            case 7:
                  display(first);
                  break;
            case 8:
                    break;
            default :
                    printf("Invalid choice!!Please Enter Correct Choice");
                    break;
        }
        
    }
    printf("\n");
}
struct Node* insertfirst(int x,struct Node *first)
{
    struct Node *new_node;
    new_node = (struct Node*) malloc(sizeof(struct Node));
    if(new_node==NULL)
    {
        printf("Overflow\n");
        return first;
    }
    else
    {
        new_node->info=x;
        if(first==NULL)
        {
            new_node->link=NULL;
            return new_node;
        }
        else
        {
            new_node->link=first; 
            return new_node;
        }
    }
}

struct Node* insertend(int x,struct Node *first)
{
    struct Node *new_node;
    struct Node *save;
    new_node = (struct Node*)malloc(sizeof(struct Node)); 
    new_node->info = x; 
    new_node->link = NULL;
    if(first==NULL)
    {
        return first;
    }
    save-first;
    while(save->link != NULL)
    {
        save = save->link;
    }
    save->link = new_node;
    return first;
}
struct Node* insertbetween(int x, struct Node *first)
{
    struct Node *new_node; 
    struct Node *save; 
    new_node = (struct Node*) malloc(sizeof(struct Node)); 
    new_node->info = x;
    if(first==NULL)
    {
        new_node->link = NULL; 
        return first;
    }
    if(new_node->info <= first->info)
    {
        new_node->link = first; 
        return first;
    }
    save-first;
    while(save->link !=NULL && (new_node->info >= (save->link)->info))
    {
        save = save->link;
    }
    new_node->link = save->link; 
    save->link = new_node;
    return first;
}
struct Node* delete(int x, struct Node *first)
{
    struct Node *save=first;
    struct Node *pred = first->link;
    if(first == NULL)
    {
        printf("\nUnderflow\n"); 
        return first;
    }
    for(int i=0;i<x-1; i++)
    {
        save = save->link;
        pred = pred->link;
    }
    save->link = pred->link;
    free(pred);
    return first;
}
int countnodes (struct Node *first)
{
    struct Node *save;
    int count=0; 
    if(first==NULL)
    {
        count=0;
        return count;
    }
    save=first; 
    while(save!=NULL)
    {
        count=count+1;
        save-save->link;
    }
    return count;
}
struct Node* copy(struct Node *first)
{
    struct Node *begin=NULL, *new_node,*save,*pred=NULL; 
    while(first!=NULL)
    {
        struct Node *new_node= (struct Node*) malloc(sizeof(struct Node));
        new_node->info = first->info;
        new_node->link =NULL;
        if(begin==NULL)
        {
            begin=new_node;
            pred=new_node;
        }
        else
        {
            pred->link=new_node; 
           pred=new_node;
        }
        first=first->link;
    }
    return begin;
}
void display (struct Node *first)
{
    struct Node *save; 
    if(first==NULL)
    {
        printf("\nLinkedList is Empty\n");
    }
    save=first; \
    while(save!=NULL)
    {
        printf(" %d ",save->info); 
        save= save->link;
    }
}