#include <stdio.h>
#include <stdlib.h>
struct Node {
  int info;
  struct Node* link;
  struct Node* prev;
};
void insertFront(struct Node** head, int info) 
{
  struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
  newNode->info = info;
  newNode->link = (*head);
  newNode->prev = NULL;
  if ((*head) != NULL)
    (*head)->prev = newNode;
  (*head) = newNode;
}
void insertAfter(struct Node* prev_node, int info) 
{
  if (prev_node == NULL) {
    printf("previous node cannot be null");
    return;
  }
  struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
  newNode->info = info;
  newNode->link = prev_node->link;
  prev_node->link = newNode;
  newNode->prev = prev_node;
  if (newNode->link != NULL)
    newNode->link->prev = newNode;
}
void insertEnd(struct Node** head, int info) 
{
  struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
  newNode->info = info;
  newNode->link = NULL;
  struct Node* temp = *head;
  if (*head == NULL) 
  {
    newNode->prev = NULL;
    *head = newNode;
    return;
  }
  while (temp->link != NULL)
    temp = temp->link;
  temp->link = newNode;
  newNode->prev = temp;
}
void deleteNode(struct Node** head, struct Node* del_node) 
{ 
  if (*head == NULL || del_node == NULL)
    return;
  if (*head == del_node)
    *head = del_node->link;
  if (del_node->link != NULL)
    del_node->link->prev = del_node->prev;
  if (del_node->prev != NULL)
    del_node->prev->link = del_node->link;
  free(del_node);
}
void displayList(struct Node* node)
{
  struct Node* last;
  while (node != NULL)
  {
    printf("%d->", node->info);
    last = node;
    node = node->link;
  }
  if (node == NULL)
    printf("NULL\n");
}
int main() 
{
  struct Node* head = NULL;
  int i;
  int op;
  while (op!=4)
  {
    printf("Enter any no:\n1.Insert in Starting\n2.Display LinkedList\n3.Delete a node\n4.Exit\n ");
    scanf("%d",&i);
    switch(i)
    {
      case 1:
      {
        int n,l;
        printf("\nEnter a no you want to Insert front first\n");
        scanf("%d",&n);
        insertFront(&head, n);
        for(i=0;i<4;i++)
        {
          printf("\nEnter a no you want to Insert next\n");
          scanf("%d",&i);
          insertAfter(head,i);
          break;
        }
      }
      case 2:
      {
        displayList(head);
        break;
      }
      case 3:
      {
        deleteNode(&head, head->link);
        break;
      }
      case 4:
      {
        break;
      }
        
    }
  }
}
}